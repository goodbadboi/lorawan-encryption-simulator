# LoRaWAN Encryption Scheme Evaluation - Final Results v1.0-rc

## 版本信息
- **版本**: v1.0-rc
- **日期**: 2024-12-25
- **Run ID**: 1756132739_616244_3a866acd
- **描述**: Final version with corrected ToA, SNR threshold, Pn calculation, and p_phy_fail semantics

## 固化参数表

### LoRa参数
- **SF**: 7
- **BW**: 125kHz
- **CR**: 4/5
- **Preamble**: 8
- **CRC**: 1
- **Header**: Explicit

### 干扰模型参数
- **SNR_threshold**: -7.5 dB
- **CAPTURE_TH_DB**: 6.0 dB
- **Time constant τ**: 0.65s
- **k_snr**: 1.5 dB
- **k_capture**: 2.0 dB

### 功率参数
- **信号功率范围**: 8-16 dBm
- **干扰器功率范围**: 6-20 dBm
- **噪声系数**: 6.0 dB
- **带宽**: 125kHz

### 分片参数
- **PHY_MAX**: 222 B
- **Overhead**: 13 B/fragment
- **重叠比例范围**: 0.35-0.65

### 测试参数
- **测试包数**: 1000
- **攻击尝试数**: 1000
- **置信区间**: 95%

## 关键结果

### SPHINCS+ 详细分析
```
🔧 ToA Debug - SPHINCS+:
   app_bytes_total: 41000B, n_frags: 197, overhead_total: 2561B
   PL_i range: 49.0-222.0B (mean: 221.1B)
   ToA_frame_mean: 0.347s, ToA_total: 68.387s
```

- **应用层数据**: 41,000 B
- **分片数**: 197
- **总开销**: 2,561 B (197 × 13B)
- **平均帧大小**: 221.1 B (接近满载222B)
- **单帧ToA**: 0.347s
- **总ToA**: 68.387s
- **干扰成功率**: 28.3% (95% CI: 25.6%-31.2%, N=1000)

### 重复性验证
- **第一次运行**: 28.3% (95% CI: 25.6%-31.2%, N=1000)
- **第二次运行**: 29.6% (95% CI: 26.9%-32.5%, N=1000)
- **结果一致性**: ✅ 两次运行结果在置信区间内重叠，验证了系统的可重复性

## 最终推荐结果

### 综合评分排名
1. **AES-128-GCM**: 0.986 (Security:97.1%, Performance:100.0%, SNR:100.0%)
2. **Hybrid-ECC-AES**: 0.935 (Security:87.0%, Performance:100.0%, SNR:100.0%)
3. **ChaCha20-Poly1305-Lite**: 0.860 (Security:72.0%, Performance:100.0%, SNR:100.0%)
4. **Advanced-ECC-AES**: 0.794 (Security:58.7%, Performance:100.0%, SNR:100.0%)

### 安全分数分解
```
Scheme Name -> Replay -> MITM -> Tamper -> KeyExt -> SideCh -> Jamming -> Core -> Other -> Final
  AES-128-GCM               -> 0.000 -> 0.121 -> 0.000 -> 0.000 -> 0.000 -> 0.082 -> 0.879 -> 0.980 -> 0.971
  Hybrid-ECC-AES            -> 0.749 -> 0.088 -> 0.000 -> 0.000 -> 0.000 -> 0.074 -> 0.251 -> 0.982 -> 0.870
  ChaCha20-Poly1305-Lite    -> 0.749 -> 0.117 -> 0.999 -> 0.000 -> 0.000 -> 0.092 -> 0.001 -> 0.977 -> 0.720
  Advanced-ECC-AES          -> 0.749 -> 0.069 -> 0.999 -> 0.000 -> 0.000 -> 0.074 -> 0.001 -> 0.732 -> 0.587
```

## 关键发现

### 1. PQC方案易受干扰的物理机制
**链条**: 分片多 → ToA长 → p_time→1 → 更易被干扰

- **SPHINCS+**: 197个分片，68.4秒ToA，28.3%干扰成功率
- **传统方案**: 1-2个分片，0.1-0.2秒ToA，<5%干扰成功率

### 2. 物理层失败概率分解
- **p_capture**: 前导/同步阶段被压制/被夺锁的概率
- **p_demod_fail**: 载荷解调因SINR不足失败的概率
- **p_phy_fail**: 物理层并联失败概率 = 1 - (1-p_capture)(1-p_demod_fail)

### 3. 时间因子饱和效应
当ToA >> τ时，p_time = 1 - exp(-ToA/τ) → 1，导致PQC方案几乎必被干扰

## 公式总结

### LoRa ToA计算 (Semtech标准)
```
T_frame = (preamble + 4.25 + payload_sym) * (2^SF / BW)
payload_sym = 8 + max(ceil((8*PL - 4*SF + 28 + 16*CRC - 20*H) / (4*(SF - 2*DE))) * (CR + 4), 0)
```

### 干扰成功率计算
```
p_capture = 1 / (1 + exp(-(delta_db - CAPTURE_TH_DB) / k_capture))
p_demod_fail = 1 / (1 + exp(-(SNR_th - sinr_db) / k_snr))
p_phy_fail = 1 - (1 - p_capture) * (1 - p_demod_fail)
p_time = 1 - exp(-ToA_total / tau)
p_jam = p_overlap * p_time * p_phy_fail
```

## 可重复性声明

### 参数来源
- **LoRa参数**: 基于LoRaWAN标准规范
- **干扰参数**: 基于LoRa捕获效应和SINR门限的物理模型
- **ToA计算**: 基于Semtech LoRa调制技术文档

### 蒙特卡洛方法
- **样本量**: N=1000 (每次攻击尝试)
- **置信区间**: 95% Wilson置信区间
- **随机种子**: 1756132739 (确保可重复性)

### 置信区间计算
使用Wilson方法计算二项比例的95%置信区间：
```
CI = p̂ ± z * sqrt(p̂(1-p̂)/n + z²/(4n²)) / (1 + z²/n)
其中 z = 1.96 (95%置信水平)
```

## 输出文件清单

### 结果文件
- `results/lorawan_simulated_packets.csv` - 网络仿真数据
- `results/simulation_report.json` - 仿真报告
- `results/attack_results.json` - 攻击测试结果
- `results/attack_results.csv` - 攻击测试CSV
- `results/security_report.json` - 安全报告

### 可视化图表
- `results/charts/performance_comparison.png` - 性能对比图
- `results/charts/security_analysis.png` - 安全分析图
- `results/charts/network_statistics.png` - 网络统计图
- `results/charts/radar_chart.png` - 雷达图
- `results/charts/timeline_analysis.png` - 时间线分析
- `results/charts/comprehensive_report.html` - 综合HTML报告

### 配置文件
- `config_final_v1.0.json` - 最终版本配置
- `FINAL_RESULTS_v1.0.md` - 本结果文档

## 版本控制
- **Git Tag**: v1.0-rc
- **Commit Message**: "Final version: corrected ToA calculation, SNR threshold sign, Pn calculation, and p_phy_fail semantics"
- **Seed**: 616244 (确保可重复性)

---

**结论**: AES-128-GCM以98.6%的综合分数成为最佳推荐方案，在保持高安全性的同时提供优异的性能和SNR表现。PQC方案因分片传输时间长而显著增加了受干扰风险，这为LoRaWAN中的加密方案选择提供了重要参考。
