# LoRaWAN Encryption Scheme Evaluation v1.0-rc

## 版本信息
- **版本**: v1.0-rc
- **日期**: 2024-12-25
- **Run ID**: 1756132739_616244_3a866acd

## 快速开始

1. 安装依赖：
```bash
pip install -r requirements.txt
```

2. 运行评估：
```bash
python main.py
```

3. 查看结果：
- 打开 `results/charts/comprehensive_report.html` 查看综合报告
- 查看 `FINAL_RESULTS_v1.0.md` 了解详细结果

## 关键发现

### SPHINCS+ 干扰分析
- **应用层数据**: 41,000 B
- **分片数**: 197
- **总ToA**: 68.387s
- **干扰成功率**: 28.3% (95% CI: 25.6%-31.2%, N=1000)

### 最终推荐
**AES-128-GCM**: 0.986 (Security:97.1%, Performance:100.0%, SNR:100.0%)

## 文件结构
- `results/` - 所有结果文件和图表
- `config_final_v1.0.json` - 固化参数配置
- `FINAL_RESULTS_v1.0.md` - 详细结果文档
- `main.py` - 主程序
- `attacks/` - 攻击测试模块
- `utils/` - 工具模块

## 可重复性
使用随机种子 1756132739 确保结果可重复。
